<?php

class BannerCustm_First_Model_Source extends Varien_Object
{
    public function toOptionArray()
  {
    return array("slide"=>"slide","fade"=>"fade");
    }
 
}