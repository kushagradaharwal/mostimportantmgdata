<?php
class BannerCustm_First_Block_Adminhtml_First extends Mage_Adminhtml_Block_Widget_Grid_Container
{
  public function __construct()
  {
    $this->_controller = 'adminhtml_first';
    $this->_blockGroup = 'first';
    $this->_headerText = Mage::helper('first')->__('Item Manager');
    $this->_addButtonLabel = Mage::helper('first')->__('Add Item');
    parent::__construct();
  }
}