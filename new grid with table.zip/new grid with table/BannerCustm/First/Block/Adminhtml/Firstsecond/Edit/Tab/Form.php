<?php

class BannerCustm_First_Block_Adminhtml_Firstsecond_Edit_Tab_Form extends Mage_Adminhtml_Block_Widget_Form
{
  protected function _prepareForm()
  {
      $form = new Varien_Data_Form();
       //$currentimage_data= Mage::registry('firstsecond_data')->getData();
      $this->setForm($form);
      $fieldset = $form->addFieldset('firstsecond_form', array('legend'=>Mage::helper('first')->__('Item information')));
        $fieldset->addField('title', 'text', array(
          'label'     => Mage::helper('first')->__('Title'),
          'class'     => 'required-entry',
          'required'  => true,
          'name'      => 'title',
      ));

      
   // $resize_source = "<img src='".Mage::getBaseUrl("media")."firstbanner/resize/".$currentimage_data['filename']."';/>";      
    //  $fieldset->addField('filename', 'file', array(
    //   'label'     => Mage::helper('first')->__('File'),
        //  'required'  => false,
         // 'name'      => 'filename',
         // 'note'     =>$resize_source,
	 // ));

		
       
      $fieldset->addField('status', 'select', array(
          'label'     => Mage::helper('first')->__('Status'),
          'name'      => 'status',
          'values'    => array(
              array(
                  'value'     => 1,
                  'label'     => Mage::helper('first')->__('Enabled'),
              ),

              array(
                  'value'     => 2,
                  'label'     => Mage::helper('first')->__('Disabled'),
              ),
          ),
      ));
     
     
     
      if ( Mage::getSingleton('adminhtml/session')->getFirstsecondData() )
      {
          $form->setValues(Mage::getSingleton('adminhtml/session')->getFirstsecondData());
         

           
          Mage::getSingleton('adminhtml/session')->setFirstsecondData(null);
      } elseif ( Mage::registry('firstsecond_data') ) {
          
         
          $form->setValues(Mage::registry('firstsecond_data')->getData());
      }
      return parent::_prepareForm();
  }
}