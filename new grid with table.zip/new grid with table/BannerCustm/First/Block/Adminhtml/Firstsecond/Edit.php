<?php

class BannerCustm_First_Block_Adminhtml_Firstsecond_Edit extends Mage_Adminhtml_Block_Widget_Form_Container
{
    public function __construct()
    {
        parent::__construct();
                 
        $this->_objectId = 'id';
        $this->_blockGroup = 'first';
        $this->_controller = 'adminhtml_firstsecond';
        
        $this->_updateButton('save', 'label', Mage::helper('first')->__('Save Item'));
        $this->_updateButton('delete', 'label', Mage::helper('first')->__('Delete Item'));
	
    }

    public function getHeaderText()
    {
      
        
        if( Mage::registry('firstsecond_data') && Mage::registry('firstsecond_data')->getId() ) {
            return Mage::helper('first')->__("Edit Item '%s'", $this->htmlEscape(Mage::registry('firstsecond_data')->getTitle()));
        } else {
            return Mage::helper('first')->__('Add Item');
        }
    }
}