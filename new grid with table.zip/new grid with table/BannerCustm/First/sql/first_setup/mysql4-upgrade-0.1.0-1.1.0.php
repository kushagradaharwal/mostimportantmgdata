<?php

$installer = $this;

$installer->startSetup();

$installer->run("ALTER TABLE `first` ADD `resizebanner` VARCHAR( 255 ) NOT NULL AFTER `filename` ;");

$installer->endSetup();

?>