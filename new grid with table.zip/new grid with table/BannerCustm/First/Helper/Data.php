<?php

class BannerCustm_First_Helper_Data extends Mage_Core_Helper_Abstract
{

public function getwidth()
{
return Mage::getStoreConfig('mycustom_section/mycustom_group/manage_width');
}

public function getheight()
{
return Mage::getStoreConfig('mycustom_section/mycustom_group/manage_hight');
}
public function gettypebanner()
{
return Mage::getStoreConfig('mycustom_section/mycustom_group/manage_animtype');
}

public function getbannerspeed()
{
return Mage::getStoreConfig('mycustom_section/mycustom_group/manage_animspeed');
}
}