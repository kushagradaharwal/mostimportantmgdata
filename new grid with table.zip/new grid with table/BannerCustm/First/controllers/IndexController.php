<?php
class BannerCustm_First_IndexController extends Mage_Core_Controller_Front_Action
{
    public function indexAction()
    {
    	
    	/*
    	 * Load an object by id 
    	 * Request looking like:
    	 * http://site.com/first?id=15 
    	 *  or
    	 * http://site.com/first/id/15 	
    	 */
    	/* 
		$first_id = $this->getRequest()->getParam('id');

  		if($first_id != null && $first_id != '')	{
			$first = Mage::getModel('first/first')->load($first_id)->getData();
		} else {
			$first = null;
		}	
		*/
		
		 /*
    	 * If no param we load a the last created item
    	 */ 
    	/*
    	if($first == null) {
			$resource = Mage::getSingleton('core/resource');
			$read= $resource->getConnection('core_read');
			$firstTable = $resource->getTableName('first');
			
			$select = $read->select()
			   ->from($firstTable,array('first_id','title','content','status'))
			   ->where('status',1)
			   ->order('created_time DESC') ;
			   
			$first = $read->fetchRow($select);
		}
		Mage::register('first', $first);
		*/

			
		$this->loadLayout();     
		$this->renderLayout();
    }
}