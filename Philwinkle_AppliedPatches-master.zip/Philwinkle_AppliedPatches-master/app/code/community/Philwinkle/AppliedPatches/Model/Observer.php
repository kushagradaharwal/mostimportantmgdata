<?php

class Philwinkle_AppliedPatches_Model_Observer
{


}

