<?php
class Kush_Salesgrid_Model_Adminhtml_System_Config_Source_Columnscollection
{
    public function toOptionArray($isMultiselect = null)
    {
      $options = array(
 
						array('value' => 'fname', 'label'=>Mage::helper('salesgrid')->__('First Name')),
						
						array('value' => 'lname', 'label'=>Mage::helper('salesgrid')->__('Last Name')),
						array('value' => 'city', 'label'=>Mage::helper('salesgrid')->__('City')),
						
						array('value' => 'region', 'label'=>Mage::helper('salesgrid')->__('Region')),
						array('value' => 'postco', 'label'=>Mage::helper('salesgrid')->__('Postcode')),
						
						array('value' => 'tphone', 'label'=>Mage::helper('salesgrid')->__('Telephone')),
						array('value' => 'email', 'label'=>Mage::helper('salesgrid')->__('Email')),
 

 
        );
 
        if(!$isMultiselect){
 
            array_unshift($options, array('value'=>'', 'label'=>Mage::helper('salesgrid')->__('--Please Select--')));
 
        }
 
        return $options;
 
    }
 
}
