#######################################################

 Magic 360™
 Magento module version v4.9.15 [v1.4.3:v4.5.12]
 
 www.magictoolbox.com
 support@magictoolbox.com

 Copyright 2014 Magic Toolbox

#######################################################

INSTALLATION:

IMPORTANT: Before you start, we recommend you open readme.txt and follow those instructions. It is faster and easier than these readme_manual.txt instructions. If installation failed using the readme.txt procedure, then continue with these instructions instead.

IMPORTANT: If you use Magento Compiler, disable it. After installation is complete, go to Magento Compiler and run the compilation process.

1. Unzip the contents and upload the app, js, media and skin folders to your Magento directory.

2. Go to 'System -> Cache Management' and refresh the cache.

3. Configure the Magic 360™ module through the 'Magic Toolbox -> Magic 360™ settings' menu in the Magento admin panel.

4. Magic 360 demo version is ready to use!

5. To upgrade your version of Magic 360 (which removes the "Please upgrade" text), buy Magic 360 and overwrite the skin/frontend/[your_interface]/[your_theme]/js/magic360.js file file with the new one in your licensed version.

Buy a single license here:

http://www.magictoolbox.com/buy/magic360/

