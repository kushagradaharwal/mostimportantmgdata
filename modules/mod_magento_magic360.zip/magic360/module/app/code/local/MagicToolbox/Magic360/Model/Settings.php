<?php

class MagicToolbox_Magic360_Model_Settings extends Mage_Core_Model_Abstract {

    protected function _construct() {
        $this->_init('magic360/settings');
    }

}
