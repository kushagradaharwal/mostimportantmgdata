<?php
class Clarion_Ajaxblog_Block_Ajaxblog extends Mage_Core_Block_Template
{
	public function _prepareLayout()
    {
       if (Mage::getSingleton("cms/wysiwyg_config")->isEnabled() && ($block = $this->getLayout()->getBlock("head"))) {
        $block->setCanLoadTinyMce(true);
        }
        return parent::_prepareLayout();
    }
    
     public function getAjaxblog()     
     { 
        if (!$this->hasData('ajaxblog')) {
            $this->setData('ajaxblogpost', Mage::registry('ajaxblog'));
        }
        return $this->getData('ajaxblog');
        
    }
    
  
    
}