<?php

class Clarion_Ajaxblog_Block_Adminhtml_Ajaxblogpost_Edit_Tab_Form extends Mage_Adminhtml_Block_Widget_Form
{
  protected function _prepareForm()
  {
      $form = new Varien_Data_Form();
      $this->setForm($form);
      
    
      $fieldset = $form->addFieldset('ajaxblogpost_form', array('legend'=>Mage::helper('ajaxblog')->__('Item information')));
     
    //  $fieldset->addField('cat_id', 'text', array(
        //  'label'     => Mage::helper('ajaxblog')->__('ID'),
          //'class'     => 'required-entry',
          //'required'  => true,
          //'name'      => 'cat_id',
      //));0
          
     // $fieldset->addField('post_id', 'text', array(
        //  'label'     => Mage::helper('ajaxblog')->__('Post ID'),
        //  'required'  => false,
        //  'name'      => 'post_id',
	 // ));

     // echo "<input type='hidden' name='postid' value ='' >":
      
      $fieldset->addField('title', 'text', array(
          'label'     => Mage::helper('ajaxblog')->__('Title'),
          'required'  => false,
          'name'      => 'title',
	  ));
      
      $noticeMessage = Mage::helper('ajaxblog')->__('e.g. domain.com/blog/<b>identifier</b>');
         $validationErrorMessage = addslashes(
            Mage::helper('ajaxblog')->__(
                "Please use only letters (a-z or A-Z), numbers (0-9) or symbols '-' and '_' in this field"
            )
        );

        $fieldset->addField(
            'identifier',
            'text',
            array(
                 'label'              => Mage::helper('ajaxblog')->__('Identifier'),
                 'class'              => 'required-entry aw-blog-validate-identifier',
                 'required'           => true,
                 'name'               => 'identifier',
                 'after_element_html' => '<span class="hint">' . $noticeMessage . '</span>'
                     . "<script>
                        Validation.add(
                            'aw-blog-validate-identifier',
                            '" . $validationErrorMessage . "',
                            function(v, elm) {
                                var regex = new RegExp(/^[a-zA-Z0-9_-]+$/);
                                return v.match(regex);
                            }
                        );
                        </script>",
            )
        );
        $categories = array();
        $collection = Mage::getModel('ajaxblog/ajaxblogcat')->getCollection()->setOrder('sort_order', 'asc');
        
    
        foreach ($collection as $cat) {
            $categories[] = (array(
                'label' => (string)$cat->getTitle(),
                'value' => $cat->getCatId()
            ));
        }

        
        $fieldset->addField(
            'categoryies',
            'multiselect',
            array(
                 'name'     => 'categoryies[]',
                 'label'    => Mage::helper('ajaxblog')->__('Category'),
                 'title'    => Mage::helper('ajaxblog')->__('Category'),
                 'required' => true,
                // 'style'    => 'height:100px',
                 'values'   => $categories,
            )
        );
        
        $fieldset->addField(
            'status',
            'select',
            array(
                 'label'              => Mage::helper('ajaxblog')->__('Status'),
                 'name'               => 'status',
                 'values'             => array(
                     array(
                         'value' => 1,
                         'label' => Mage::helper('ajaxblog')->__('Enabled'),
                     ),
                     array(
                         'value' => 2,
                         'label' => Mage::helper('ajaxblog')->__('Disabled'),
                     ),
                     array(
                         'value' => 3,
                         'label' => Mage::helper('ajaxblog')->__('Hidden'),
                     ),
                 ),
                 'after_element_html' => '<span class="hint">'
                     . Mage::helper('ajaxblog')->__(
                         "Hidden pages won't be shown in blog but still can be accessed directly"
                     )
                     . '</span>',
            )
        );


        $fieldset->addField(
            'comments',
            'select',
            array(
                 'label'              => Mage::helper('ajaxblog')->__('Enable Comments'),
                 'name'               => 'comments',
                 'values'             => array(
                     array(
                         'value' => 0,
                         'label' => Mage::helper('ajaxblog')->__('Enabled'),
                     ),
                     array(
                         'value' => 1,
                         'label' => Mage::helper('ajaxblog')->__('Disabled'),
                     ),
                 ),
                 'after_element_html' => '<span class="hint">'
                     . Mage::helper('ajaxblog')->__(
                         'Disabling will close the post to new comments'
                     )
                     . '</span>',
            )
        );

        $configSettings = Mage::getSingleton('cms/wysiwyg_config')->getConfig(
array(
'add_widgets' => false,
'add_variables' => false,
'add_images' => false,
'files_browser_window_url'=> $this->getBaseUrl().'admin/cms_wysiwyg_images/index/',
));
 
$fieldset->addField('post_content', 'editor', array(
'name' => 'post_content',
'label' => Mage::helper('ajaxblog')->__('Post Content'),
'title' => Mage::helper('ajaxblog')->__('Post Content'),
'style' => 'width:700px; height:320px;',
'wysiwyg' => true,
'required' => true,
'config' => $configSettings,
));

    

      if ( Mage::getSingleton('adminhtml/session')->getAjaxblogData() )
      {
          $form->setValues(Mage::getSingleton('adminhtml/session')->getAjaxblogData());
          Mage::getSingleton('adminhtml/session')->setAjaxblogData(null);
      } elseif ( Mage::registry('ajaxblogpost_data') ) {
          $form->setValues(Mage::registry('ajaxblogpost_data')->getData());
      }
      return parent::_prepareForm();
  }
}