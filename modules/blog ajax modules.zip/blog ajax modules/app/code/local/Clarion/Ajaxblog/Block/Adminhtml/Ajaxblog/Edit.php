<?php

class Clarion_Ajaxblog_Block_Adminhtml_Ajaxblog_Edit extends Mage_Adminhtml_Block_Widget_Form_Container
{
    public function __construct()
    {
        parent::__construct();
                 
        $this->_objectId = 'id';
        $this->_blockGroup = 'ajaxblog';
        $this->_controller = 'adminhtml_ajaxblog';
        
        $this->_updateButton('save', 'label', Mage::helper('ajaxblog')->__('Save Item'));
        $this->_updateButton('delete', 'label', Mage::helper('ajaxblog')->__('Delete Item'));
		
        $this->_addButton('saveandcontinue', array(
            'label'     => Mage::helper('adminhtml')->__('Save And Continue Edit'),
            'onclick'   => 'saveAndContinueEdit()',
            'class'     => 'save',
        ), -100);

        $this->_formScripts[] = "
            function toggleEditor() {
                if (tinyMCE.getInstanceById('ajaxblog_content') == null) {
                    tinyMCE.execCommand('mceAddControl', false, 'ajaxblog_content');
                } else {
                    tinyMCE.execCommand('mceRemoveControl', false, 'ajaxblog_content');
                }
            }

            function saveAndContinueEdit(){
                editForm.submit($('edit_form').action+'back/edit/');
            }
        ";
    }

    public function getHeaderText()
    {
        if( Mage::registry('ajaxblog_data') && Mage::registry('ajaxblog_data')->getId() ) {
            return Mage::helper('ajaxblog')->__("Edit Item '%s'", $this->htmlEscape(Mage::registry('ajaxblog_data')->getTitle()));
        } else {
            return Mage::helper('ajaxblog')->__('Add Item');
        }
    }
}