<?php
class Clarion_Ajaxblog_Block_Ajaxblogcat extends Mage_Core_Block_Template
{
	public function _prepareLayout()
    {
       if (Mage::getSingleton("cms/wysiwyg_config")->isEnabled() && ($block = $this->getLayout()->getBlock("head"))) {
        $block->setCanLoadTinyMce(true);
        }
        return parent::_prepareLayout();
    }
    
     public function getAjaxblog()     
     { 
        if (!$this->hasData('ajaxblogcat')) {
            $this->setData('ajaxblogcat', Mage::registry('ajaxblogcat'));
        }
        return $this->getData('ajaxblogcat');
        
    }
  
     
}