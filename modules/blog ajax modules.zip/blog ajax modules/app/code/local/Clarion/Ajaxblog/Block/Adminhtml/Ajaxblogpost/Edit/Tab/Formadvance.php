<?php

class Clarion_Ajaxblog_Block_Adminhtml_Ajaxblogpost_Edit_Tab_Formadvance extends Mage_Adminhtml_Block_Widget_Form
{
  protected function _prepareForm()
  {
      $form = new Varien_Data_Form();
      $this->setForm($form);
      $fieldset = $form->addFieldset('ajaxblogpost_form', array('legend'=>Mage::helper('ajaxblog')->__('Item information')));
      $fieldset->addField(
            'meta_keywords',
            'editor',
            array(
                 'name'  => 'meta_keywords',
                 'label' => Mage::helper('ajaxblog')->__('Keywords'),
                 'title' => Mage::helper('ajaxblog')->__('Meta Keywords'),
                 'style' => 'width: 520px;',
            )
        );

        $fieldset->addField(
            'meta_description',
            'editor',
            array(
                 'name'  => 'meta_description',
                 'label' => Mage::helper('ajaxblog')->__('Description'),
                 'title' => Mage::helper('ajaxblog')->__('Meta Description'),
                 'style' => 'width: 520px;',
            )
        );

        $fieldset = $form->addFieldset(
            'blog_options', array('legend' => Mage::helper('ajaxblog')->__('Advanced Post Options'))
        );

        $fieldset->addField(
            'user',
            'text',
            array(
                 'label'              => Mage::helper('ajaxblog')->__('Poster'),
                 'name'               => 'user',
                 'style'              => 'width: 520px;',
                 'after_element_html' => '<span class="hint">'
                     . Mage::helper('ajaxblog')->__('Leave blank to use current user name')
                     . '</span>',
            )
        );

        $outputFormat = Mage::app()->getLocale()->getDateTimeFormat(Mage_Core_Model_Locale::FORMAT_TYPE_MEDIUM);

        $fieldset->addField(
            'created_time',
            'date',
            array(
                 'name'   => 'created_time',
                 'label'  => $this->__('Created on'),
                 'title'  => $this->__('Created on'),
                 'image'  => $this->getSkinUrl('images/grid-cal.gif'),
                 'format' => $outputFormat,
                 'time'   => true,
            )
        );



      if ( Mage::getSingleton('adminhtml/session')->getAjaxblogData() )
      {
          $form->setValues(Mage::getSingleton('adminhtml/session')->getAjaxblogData());
          Mage::getSingleton('adminhtml/session')->setAjaxblogData(null);
      } elseif ( $data  = Mage::registry('ajaxblogpost_data') ) {
          $form->setValues(Mage::registry('ajaxblogpost_data')->getData());
		  if ($data->getData('created_time')) {
                $form->getElement('created_time')->setValue(
                    Mage::app()->getLocale()->date(
                        $data->getData('created_time'), Varien_Date::DATETIME_INTERNAL_FORMAT
                    )
                );
            }
			
      }
      return parent::_prepareForm();
  }
}