<?php

class Clarion_Ajaxblog_Block_Adminhtml_Ajaxblogcat_Edit extends Mage_Adminhtml_Block_Widget_Form_Container
{
    public function __construct()
    {
        parent::__construct();
                 
        $this->_objectId = 'cat_id';
        $this->_blockGroup = 'ajaxblog';
        $this->_controller = 'adminhtml_ajaxblogcat';
        
        $this->_updateButton('save', 'label', Mage::helper('ajaxblog')->__('Save Item'));
        $this->_updateButton('delete', 'label', Mage::helper('ajaxblog')->__('Delete Item'));
		
        $this->_addButton('saveandcontinue', array(
            'label'     => Mage::helper('adminhtml')->__('Save And Continue Edit'),
            'onclick'   => 'saveAndContinueEdit()',
            'class'     => 'save',
        ), -100);

        $this->_formScripts[] = "
            function toggleEditor() {
                if (tinyMCE.getInstanceById('ajaxblogcat_content') == null) {
                    tinyMCE.execCommand('mceAddControl', false, 'ajaxblogcat_content');
                } else {
                    tinyMCE.execCommand('mceRemoveControl', false, 'ajaxblogcat_content');
                }
            }

            function saveAndContinueEdit(){
                editForm.submit($('edit_form').action+'back/edit/');
            }
        ";
    }

    public function getHeaderText()
    {
        if( Mage::registry('ajaxblogcat_data') && Mage::registry('ajaxblogcat_data')->getId() ) {
            return Mage::helper('ajaxblog')->__("Edit Item '%s'", $this->htmlEscape(Mage::registry('ajaxblogcat_data')->getTitle()));
        } else {
            return Mage::helper('ajaxblog')->__('Add Item');
        }
    }
}