<?php

$installer = $this;

$installer->startSetup();

$installer->run("ALTER TABLE `ajaxblogpost` ADD `categoryies` VARCHAR( 255 ) NULL AFTER `cat_id`");
$installer->endSetup(); 