<?php
class Clarion_Ajaxblog_Block_Ajaxblogcomment extends Mage_Core_Block_Template
{
    
    
   protected function _construct()
    {
        parent::_construct();
        $this->setTemplate('ajaxblog/ajaxblogpostcommsave.phtml');
    }

    
    
    
    
  
    
}