<?php

$installer = $this;

$installer->startSetup();

$installer->run("

-- DROP TABLE IF EXISTS {$this->getTable('ajaxblogcat')};
CREATE TABLE {$this->getTable('ajaxblogcat')} (
  `cat_id` int(11) unsigned NOT NULL auto_increment,
  `title` varchar(255) NOT NULL default '',
  `sort_order` tinyint ( 6 ) NOT NULL ,
  `meta_keywords` text NOT NULL ,
  `meta_description` text NOT NULL ,
  PRIMARY KEY (`cat_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;");

$installer->endSetup(); 