<?php
class Clarion_Ajaxblog_PostController extends Mage_Core_Controller_Front_Action
{
    public function indexAction()
    {$this->getResponse()->clearHeaders()->setHeader('Content-type','application/json',true);
    	
    	/*
    	 * Load an object by id 
    	 * Request looking like:
    	 * http://site.com/ajaxblog?id=15 
    	 *  or
    	 * http://site.com/ajaxblog/id/15 	
    	 */
    	/* 
		$ajaxblog_id = $this->getRequest()->getParam('id');

  		if($ajaxblog_id != null && $ajaxblog_id != '')	{
			$ajaxblog = Mage::getModel('ajaxblog/ajaxblog')->load($ajaxblog_id)->getData();
		} else {
			$ajaxblog = null;
		}	
		*/
		
		 /*
    	 * If no param we load a the last created item
    	 */ 
    	/*
    	if($ajaxblog == null) {
			$resource = Mage::getSingleton('core/resource');
			$read= $resource->getConnection('core_read');
			$ajaxblogTable = $resource->getTableName('ajaxblog');
			
			$select = $read->select()
			   ->from($ajaxblogTable,array('ajaxblog_id','title','content','status'))
			   ->where('status',1)
			   ->order('created_time DESC') ;
			   
			$ajaxblog = $read->fetchRow($select);
		}
		Mage::register('ajaxblog', $ajaxblog);
		*/

			
		$this->loadLayout();     
		$this->renderLayout();
    }
    
    
    
    
     public function postAction()
     {
      
       $postid =$_POST["id"];

        if (!$this->getRequest()->isXmlHttpRequest()) {
            $this->_redirect('/');
        }
        
       $this->getResponse()->setBody($this->getLayout()->createBlock('ajaxblog/ajaxblogpost')
        ->setId($postid)
        ->toHtml());
    }
    
    
    public  function comm_saveingAction()
    {
        //echo $_POST['idcall'];
       // echo "2-144444444444444444";
       //// die;
       $postdata =$this->getRequest()->getParams();
       
       echo $postdata['idcall'];
     //  die;
          if (!$this->getRequest()->isXmlHttpRequest()) {
            $this->_redirect('/');
        }
     
       $this->getResponse()->setBody($this->getLayout()->createBlock('ajaxblog/ajaxblogpostcommsave')
        ->setPostId($postdata['idcall'])
        ->toHtml());
       
       //$orderfeedback_id =$this->getRequest()->getParams();

   
        //if (!$this->getRequest()->isXmlHttpRequest()) {
          //  $this->_redirect('/');
        //}
        
      //  $this->getResponse()->setBody($this->getLayout()->createBlock('orderfeedback/orderdata')
        //->setOrderid($orderfeedback_id['entity'])
        //->setIncorderid($orderfeedback_id['incid'])        
        //->toHtml());
        
    }
    public function commentsaveAction()
     {
         
        echo '<pre>';
              print_r($_POST); die;
                if (!$this->getRequest()->isXmlHttpRequest()) {
            $this->_redirect('/');
        }
     
       $this->getResponse()->setBody($this->getLayout()->createBlock('ajaxblog/ajaxblogpostcommsave')
        ->setId($_POST['post_id'])
        ->toHtml());
      // $data =  $this->getRequest()->getPost();
      // $model  = Mage::getModel("ajaxblog/ajaxblogcomment"); //load comment model
      //// $model->setData($data)
             //->setPostId($data['post_id']);
       //$model->save();
       // if( $model->save())
           // {
               // $success_message = Mage::helper("ajaxblog")->getSucessmessage();
             //   Mage::getSingleton('core/session')->addSuccess(Mage::helper('ajaxblog')->__("Comment Saved Sucessfully"));
         // //  } 
          
       // $returnurl = Mage::getUrl("blog/post/post");
       
       //echo $this->_redirectUrl("orderfeedback/orderfeedback/view/");
       //die;
      // $this->_redirectUrl(Mage::getUrl("blog"));
     }
    
     
      
     public function blogajaxcosaveAction()
     {
       if (!$this->getRequest()->isXmlHttpRequest()) {
            $this->_redirect('/');
        }
        
        $data =  $this->getRequest()->getPost();
        
       // echo '<pre>';print_r($data);die;
          if(isset($data['post_id']))
          {
          $model  = Mage::getModel("ajaxblog/ajaxblogcomment"); //load comment model
          $model->setData($data)
                ->setPostId($data['post_id']);
          $model->save();
             if($model->save())
               {
                  $success_message = Mage::helper("ajaxblog")->getSucessmessage();
                  Mage::getSingleton('core/session')->addSuccess(Mage::helper('ajaxblog')->__("Comment Saved Sucessfully"));
                } 
                
        $this->getResponse()->setBody($this->getLayout()->createBlock('ajaxblog/ajaxblogpostcommsave')
        ->setPostId($data['post_id'])
        ->setCatId($data['catid'])
        ->toHtml());
        
       ///
       ///echo "<pre>";
     // print_r($_POST['post_id']);
          

          // $returnurl = Mage::getUrl("blog/post/post");

          // echo $this->_redirectUrl("orderfeedback/orderfeedback/view/");
           //die;
         //  $this->_redirectUrl(Mage::getUrl("blog"));

         }
     }
    
    
}