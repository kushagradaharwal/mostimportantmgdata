<?php
class Clarion_Ajaxblog_PostController extends Mage_Core_Controller_Front_Action
{
    public function indexAction()
    {
	    $this->getResponse()->clearHeaders()->setHeader('Content-type','application/json',true);
    	$this->loadLayout();     
		$this->renderLayout();
    }
    
    
    
    
     public function postAction()
     {
       $params = $this->getRequest()->getParams();
      
       // $postid = $_POST["id"];
        
        if (!$this->getRequest()->isXmlHttpRequest()) {
           $this->_redirect('/');
      }
       $this->loadLayout();
       $post_block = array();
       $post_block['message'] = "Post";
       $post_block['post_block'] = $this->getLayout()->createBlock('ajaxblog/ajaxblogpost')->toHtml();
       $this->getResponse()->setBody(json_encode($post_block));
       
     }
     
     
	 public function checkpostAction()
     {
        $params = $this->getRequest()->getParams();
      
        $postid = $_POST["id"];
        
        if (!$this->getRequest()->isXmlHttpRequest()) {
            $this->_redirect('/');
        }
        $this->loadLayout();
        $post_block = array();
        $post_block['message'] = "Post";
        $post_block['post_block'] = $this->getLayout()->createBlock('ajaxblog/postcheck')->toHtml();
        $this->getResponse()->setBody(json_encode($post_block));
       
     }
	 
     
    public  function comm_saveingAction()
    {
        //echo $_POST['idcall'];
       // echo "2-144444444444444444";
       //// die;
       $postdata =$this->getRequest()->getParams();
       
       echo $postdata['idcall'];
     //  die;
          if (!$this->getRequest()->isXmlHttpRequest()) {
            $this->_redirect('/');
        }
     
       $this->getResponse()->setBody($this->getLayout()->createBlock('ajaxblog/ajaxblogpostcommsave')
        ->setPostId($postdata['idcall'])
        ->toHtml());
       
       //$orderfeedback_id =$this->getRequest()->getParams();

   
        //if (!$this->getRequest()->isXmlHttpRequest()) {
          //  $this->_redirect('/');
        //}
        
      //  $this->getResponse()->setBody($this->getLayout()->createBlock('orderfeedback/orderdata')
        //->setOrderid($orderfeedback_id['entity'])
        //->setIncorderid($orderfeedback_id['incid'])        
        //->toHtml());
        
    }
    public function commentsaveAction()
     {
         
        echo '<pre>';
              print_r($_POST); die;
                if (!$this->getRequest()->isXmlHttpRequest()) {
            $this->_redirect('/');
        }
     
       $this->getResponse()->setBody($this->getLayout()->createBlock('ajaxblog/ajaxblogpostcommsave')
        ->setId($_POST['post_id'])
        ->toHtml());
      // $data =  $this->getRequest()->getPost();
      // $model  = Mage::getModel("ajaxblog/ajaxblogcomment"); //load comment model
      //// $model->setData($data)
             //->setPostId($data['post_id']);
       //$model->save();
       // if( $model->save())
           // {
               // $success_message = Mage::helper("ajaxblog")->getSucessmessage();
             //   Mage::getSingleton('core/session')->addSuccess(Mage::helper('ajaxblog')->__("Comment Saved Sucessfully"));
         // //  } 
          
       // $returnurl = Mage::getUrl("blog/post/post");
       
       //echo $this->_redirectUrl("orderfeedback/orderfeedback/view/");
       //die;
      // $this->_redirectUrl(Mage::getUrl("blog"));
     }
    
     
      
     public function blogajaxcosaveAction()
     {
      // if (!$this->getRequest()->isXmlHttpRequest()) {
            //$this->_redirect('/');
       // }
        
        $data =  $this->getRequest()->getPost();
        
      //echo '<pre>';print_r($data);die;
//[post_id] => 9
  //  [name] => kushagrta
    //[email] => hh@yahoo.com
    //[comment] => Testingaaaa Default Comment      
          if(isset($data['post_id']))
          {
          $model  = Mage::getModel("ajaxblog/ajaxblogcomment"); //load comment model
          $model->setData($data)
                ->setPostId($data['post_id']);
          $model->save();
          
          $this->loadLayout();
           
          $comment_block = array();
         
          $success_message = Mage::helper("ajaxblog")->getSucessmessage();
       
          $comment_block['comment_msg']  = "<span class=blog-ajaxcommentsavedmessage>Comment Saved Sucessfully</span>";
          
         
        
          //$comment_block['comment_block'] = $this->getLayout()->createBlock('ajaxblog/ajaxblogpostcommsave')->toHtml();
		  
		  //$comment_block['comment_block'] = "";

         
          $this->getResponse()->setBody(json_encode($comment_block));
        
       // $this->getResponse()->setBody($this->getLayout()->createBlock('ajaxblog/ajaxblogpostcommsave')
        //->setPostId($data['post_id'])
        //->setCatId($data['catid'])
        //->toHtml());
        
       ///
       ///echo "<pre>";
     // print_r($_POST['post_id']);
          

          // $returnurl = Mage::getUrl("blog/post/post");

          // echo $this->_redirectUrl("orderfeedback/orderfeedback/view/");
           //die;
         //  $this->_redirectUrl(Mage::getUrl("blog"));

         }
     }
    
	public function postdetailAction()
     {  
	    if (!$this->getRequest()->isXmlHttpRequest()) {
            $this->_redirect('/');
        }
        $this->loadLayout();
        $post_block = array();
        $post_block['message'] = "ReadMorePost";
        $post_block['single_post_block'] = $this->getLayout()->createBlock('ajaxblog/ajaxblogsinglepost')->toHtml();
        $this->getResponse()->setBody(json_encode($post_block));
	}
}