<?php
class Clarion_Ajaxblog_Postcontroller extends Mage_Core_Controller_Front_Action
{
    public function indexAction()
    {   $this->loadLayout();     
	$this->renderLayout();
    }
    
    
    public function postAction()
    {
      echo "post action";
      die;
       $postid =$_POST["id"];

        if (!$this->getRequest()->isXmlHttpRequest()) {
            $this->_redirect('/');
        }
        
       $this->getResponse()->setBody($this->getLayout()->createBlock('ajaxblog/ajaxblogpost')
        ->setId($postid)
        ->toHtml());
    }
    

    
    
}