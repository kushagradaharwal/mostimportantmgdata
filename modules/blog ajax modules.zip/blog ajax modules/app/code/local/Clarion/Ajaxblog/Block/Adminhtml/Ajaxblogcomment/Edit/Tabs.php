<?php

class Clarion_Ajaxblog_Block_Adminhtml_Ajaxblogcomment_Edit_Tabs extends Mage_Adminhtml_Block_Widget_Tabs
{

  public function __construct()
  {
   
      $this->setId('ajaxblogcomment_tabs');
      $this->setDestElementId('edit_form');
      $this->setTitle(Mage::helper('ajaxblog')->__('Item Information'));
         parent::__construct();
  }

  protected function _beforeToHtml()
  {
      $this->addTab('form_section', array(
          'label'     => Mage::helper('ajaxblog')->__('Item Information'),
          'title'     => Mage::helper('ajaxblog')->__('Item Information'),
          'content'   => $this->getLayout()->createBlock('ajaxblog/adminhtml_Ajaxblogcomment_edit_tab_form')->toHtml(),
      ));
     
      return parent::_beforeToHtml();
  }
}