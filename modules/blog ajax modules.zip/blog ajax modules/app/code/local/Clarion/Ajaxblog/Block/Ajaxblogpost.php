<?php
class Clarion_Ajaxblog_Block_Ajaxblogpost extends Mage_Core_Block_Template
{   
    protected function _construct()
    {
        parent::_construct();
        $this->setTemplate("ajaxblog/ajaxblogpost.phtml");
    }
    
    
    public function _prepareLayout()
    {
       if (Mage::getSingleton("cms/wysiwyg_config")->isEnabled() && ($block = $this->getLayout()->getBlock("head"))) {
        $block->setCanLoadTinyMce(true);
        }
        return parent::_prepareLayout();
    }
    
    public function getAjaxblog()     
     { 
        if (!$this->hasData('ajaxblogpost')) {
            $this->setData('ajaxblogpost', Mage::registry('ajaxblogpost'));
        }
        return $this->getData('ajaxblogpost');
        
     }
    
     public function  mysql_connectfunc()
	  {
	         return  Mage::getSingleton('core/resource')->getConnection('core_write');
	  }
             
    
     public function getPosts()     
     { 
        if(isset($_POST['id']))
        {    
          
            $result  = $this->mysql_connectfunc()->query("SELECT *  from ajaxblogpost where FIND_IN_SET(".$_POST['id'].",ajaxblogpost.categoryies)");
            
            $collection = $result->fetchAll();
            
            return $collection; 
        }
     }
     
  


     public function getRecentPosts()     
     { 
            $result_recent  = $this->mysql_connectfunc()->query("SELECT * from ajaxblogpost where ajaxblogpost.status=1 group by ajaxblogpost.post_id ASC LIMIT 0 , 5");
             
            $recent_possts = $result_recent->fetchAll();
            
            return $recent_possts; 
       
     }
    
	 public function getPostComment($_postid)     
     { 
			$result_comment  = $this->mysql_connectfunc()->query("SELECT * from ajaxblogcomment where ajaxblogcomment.status=1 AND ajaxblogcomment.post_id='".$_postid."' order by ajaxblogcomment.comment_id ASC LIMIT 0 , 5");
             
            $recent_comment  = $result_comment ->fetchAll();
            //echo '<pre>';print_r($recent_comment);
			
            return $recent_comment; 
       
    }
	
	 public function getReadMoreLink($_postid)     
     { 
			$_readmore = Mage::getBaseUrl()."blog/post/postdetail/?post_id=".$_postid;
            return $_readmore; 
       
     }
	 
    
	 public function getParentComment($_postid)     
     { 
			$result_comment  = $this->mysql_connectfunc()->query("SELECT * from ajaxblogcomment where ajaxblogcomment.status=1 && ajaxblogcomment.post_id='".$_postid."' order by ajaxblogcomment.comment_id ASC LIMIT 0 , 5");
             
            $recent_comment  = $result_comment ->fetchAll();
            
	 }
     
	 
	 

}

