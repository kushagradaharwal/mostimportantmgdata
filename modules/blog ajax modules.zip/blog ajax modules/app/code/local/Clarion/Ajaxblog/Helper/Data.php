<?php

class Clarion_Ajaxblog_Helper_Data extends Mage_Core_Helper_Abstract
{
   
    public function getbasecatUrl()
    {
       return   Mage::getBaseUrl().'blog/post/post';
       // return   Mage::getBaseUrl().'blog/post/checkpost';
    }
    
    public function getCommentformUrl()
    {
        return   Mage::getBaseUrl().'blog/post/commentsave';
    }
    
    public function getSucessmessage()
    {
        return   "Comment saved...";
    }
    
	public function getBackbuttonurl()
    {
         return   Mage::getBaseUrl().'blog/post/commentsave';
    }
    
	
	public function getSenderemail()
    {
           return Mage::getStoreConfig("ajaxblog/ajaxblogcomment/commentemaildsender");
    }
   
    public function getSenderename()
    {
           return Mage::getStoreConfig("ajaxblog/ajaxblogcomment/commentsendemail");
    }
 
    
      public function getDefaultSenderemail()
    {
           return Mage::getStoreConfig("trans_email/ident_general/email");
    }
 
    
      public function getDefaultSendername()
    {
           return Mage::getStoreConfig("trans_email/ident_general/name");
    }
 
   
      public function getEmailsubCustomer()
    {
           return Mage::getStoreConfig("orderfeedback/orderfeedback/email_tempalte_subject_frontend");
    }
 

}