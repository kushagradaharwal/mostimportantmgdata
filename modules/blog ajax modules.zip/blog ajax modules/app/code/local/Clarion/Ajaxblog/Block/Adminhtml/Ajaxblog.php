<?php
class Clarion_Ajaxblog_Block_Adminhtml_Ajaxblog extends Mage_Adminhtml_Block_Widget_Grid_Container
{
  public function __construct()
  {
    $this->_controller = 'adminhtml_ajaxblog';
    $this->_blockGroup = 'ajaxblog';
    $this->_headerText = Mage::helper('ajaxblog')->__('Item Manager');
    $this->_addButtonLabel = Mage::helper('ajaxblog')->__('Add Item');
    parent::__construct();
  }
}