<?php
class Clarion_Ajaxblog_Block_Postcheck extends Mage_Core_Block_Template
{   
    protected function _construct()
    {
        parent::_construct();
        $this->setTemplate("ajaxblog/postcheck.phtml");
    }
    
    
    public function _prepareLayout()
    {
       if (Mage::getSingleton("cms/wysiwyg_config")->isEnabled() && ($block = $this->getLayout()->getBlock("head"))) {
        $block->setCanLoadTinyMce(true);
        }
        return parent::_prepareLayout();
    }
    
     public function getAjaxblog()     
     { 
        if (!$this->hasData('ajaxblogpost')) {
            $this->setData('ajaxblogpost', Mage::registry('ajaxblogpost'));
        }
        return $this->getData('ajaxblogpost');
        
    }
    
   
     
  public function  mysql_connectfunc()
             {
              return  Mage::getSingleton('core/resource')->getConnection('core_write');
             }

  public function getColdata()
  {
      if(isset($_POST['id']))
        {    
          
            $result  = $this->mysql_connectfunc()->query("SELECT *  from ajaxblogpost where FIND_IN_SET(".$_POST['id'].",ajaxblogpost.categoryies)");
            
            $collection = $result->fetchAll();
           // echo '<pre>';print_r($collection);
			//die;
            return $collection;
        }
    
}    

}

