<?php
class Clarion_Ajaxblog_Block_Ajaxblogsinglepost extends Mage_Core_Block_Template
{   
    protected function _construct()
    {
        parent::_construct();
        $this->setTemplate("ajaxblog/ajaxblogsinglepost.phtml");
    }
    
    
    public function _prepareLayout()
    {
       if (Mage::getSingleton("cms/wysiwyg_config")->isEnabled() && ($block = $this->getLayout()->getBlock("head"))) {
        $block->setCanLoadTinyMce(true);
        }
        return parent::_prepareLayout();
    }
    
   

}

