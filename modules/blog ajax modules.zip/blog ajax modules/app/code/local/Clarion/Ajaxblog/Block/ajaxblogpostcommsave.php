<?php
class Clarion_Ajaxblog_Block_Ajaxblogpostcommsave extends Mage_Core_Block_Template
{   
   
    protected function _construct()
    {
        parent::_construct();
        $this->setTemplate('ajaxblog/ajaxblogpostcommsave.phtml');
    }
  
    public  function getPostidcomment()
    {
       return $_POST['post_id']; //post id of post
       
    }
    
    public  function getCatidcomment()
    { 
       return $_POST['catid']; //cat id of cat
       
    }
    
    
    public function  mysql_connectfunc()
    {
       return  Mage::getSingleton('core/resource')->getConnection('core_write');
    }
             
    public function getPosts()     
    { 
        if($this->getCatidcomment())
        {    

            $result  = $this->mysql_connectfunc()->query("SELECT *  from ajaxblogpost where FIND_IN_SET(".$this->getCatidcomment().",ajaxblogpost.categoryies)");

            $collection = $result->fetchAll();
           
         
            return $collection; 
        }
    }

     public function getRecentPosts()     
     { 
            $result_recent  = $this->mysql_connectfunc()->query("SELECT * from ajaxblogpost where ajaxblogpost.status=1 order by ajaxblogpost.post_id ASC LIMIT 0 , 5");
             
            $recent_possts = $result_recent->fetchAll();
            
            return $recent_possts; 
       
    }
    
     public function getPostCategories()     
     { 
            
           $postidarray  = $this->mysql_connectfunc()->query("SELECT ajaxblogpost.post_id from ajaxblogpost where ajaxblogpost.status=1 order by ajaxblogpost.post_id ASC LIMIT 0 , 5");
             
           $recent_possts = $postidarray->fetchAll();
           
           
           return $recent_possts; 
       
    }
}