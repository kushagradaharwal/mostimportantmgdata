<?php

class Clarion_Ajaxblog_Block_Adminhtml_Ajaxblogpost_Grid extends Mage_Adminhtml_Block_Widget_Grid
{
  public function __construct()
  {
      parent::__construct();
      $this->setId('ajaxblogpostGrid');
      $this->setDefaultSort('post_id');
      $this->setDefaultDir('ASC');
      $this->setSaveParametersInSession(true);
  }

  protected function _prepareCollection()
  {
      $collection = Mage::getModel('ajaxblog/ajaxblogpost')->getCollection();
      
      
      //echo '<pre>';print_r($collection->getData());
     // die;
      $this->setCollection($collection);
      return parent::_prepareCollection();
  }

  protected function _prepareColumns()
  {
      $this->addColumn('post_id', array(
          'header'    => Mage::helper('ajaxblog')->__('ID'),
          'align'     =>'right',
          'width'     => '50px',
          'index'     => 'post_id',
      ));

     
      $this->addColumn('title', array(
          'header'    => Mage::helper('ajaxblog')->__('Title'),
          'align'     =>'left',
          'index'     => 'title',
      ));
        
      $this->addColumn('status', array(
          'header'    => Mage::helper('ajaxblog')->__('Status'),
          'align'     => 'left',
          'width'     => '80px',
          'index'     => 'status',
          'type'      => 'options',
          'options'   => array(
              1 => 'Approve',
              2 => 'Unapprove',

          ),
      ));
      
        $this->addColumn('categoryies', array(
          'header'    => Mage::helper('ajaxblog')->__('Category Id'),
          'align'     =>'left',
          'index'     => 'categoryies',
      ));
        
      $this->addColumn('user', array(
          'header'    => Mage::helper('ajaxblog')->__('User'),
          'align'     =>'left',
          'index'     => 'user',
      ));
      
      
      
      
       
	  
        $this->addColumn('action',
            array(
                'header'    =>  Mage::helper('ajaxblog')->__('Action'),
                'width'     => '100',
                'type'      => 'action',
                'getter'    => 'getId',
                'actions'   => array(
                    array(
                        'caption'   => Mage::helper('ajaxblog')->__('Edit'),
                        'url'       => array('base'=> '*/*/edit'),
                        'field'     => 'id'
                    )
                ),
                'filter'    => false,
                'sortable'  => false,
                'index'     => 'stores',
                'is_system' => true,
        ));
		
		$this->addExportType('*/*/exportCsv', Mage::helper('ajaxblog')->__('CSV'));
		$this->addExportType('*/*/exportXml', Mage::helper('ajaxblog')->__('XML'));
	  
      return parent::_prepareColumns();
  }

    protected function _prepareMassaction()
    {
        $this->setMassactionIdField('ID');
        $this->getMassactionBlock()->setFormFieldName('ajaxblogcomment');

        $this->getMassactionBlock()->addItem('delete', array(
             'label'    => Mage::helper('ajaxblog')->__('Delete'),
             'url'      => $this->getUrl('*/*/massDelete'),
             'confirm'  => Mage::helper('ajaxblog')->__('Are you sure?')
        ));

        $statuses = Mage::getSingleton('ajaxblog/status')->getOptionArray();

        array_unshift($statuses, array('label'=>'', 'value'=>''));
        $this->getMassactionBlock()->addItem('status', array(
             'label'=> Mage::helper('ajaxblog')->__('Change status'),
             'url'  => $this->getUrl('*/*/massStatus', array('_current'=>true)),
             'additional' => array(
                    'visibility' => array(
                         'name' => 'status',
                         'type' => 'select',
                         'class' => 'required-entry',
                         'label' => Mage::helper('ajaxblog')->__('Status'),
                         'values' => $statuses
                     )
             )
        ));
        return $this;
    }

  public function getRowUrl($row)
  {
      return $this->getUrl('*/*/edit', array('id' => $row->getId()));
  }

}