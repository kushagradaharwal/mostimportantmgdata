<?php

class Clarion_Ajaxblog_Block_Adminhtml_Ajaxblogpost_Edit_Tabs extends Mage_Adminhtml_Block_Widget_Tabs
{

  public function __construct()
  {
   
      $this->setId('ajaxblogpost_tabs');
      $this->setDestElementId('edit_form');
      $this->setTitle(Mage::helper('ajaxblog')->__('Item Information'));
      parent::__construct();
  }

  protected function _beforeToHtml()
  {
      $this->addTab('form_section', array(
          'label'     => Mage::helper('ajaxblog')->__('Item Information'),
          'title'     => Mage::helper('ajaxblog')->__('Item Information'),
          'content'   => $this->getLayout()->createBlock('ajaxblog/adminhtml_Ajaxblogpost_edit_tab_form')->toHtml(),
      ));
      
       $this->addTab('form_sectionss', array(
          'label'     => Mage::helper('ajaxblog')->__('Advanced Options'),
          'title'     => Mage::helper('ajaxblog')->__('AdvancedItem Options'),
          'content'   => $this->getLayout()->createBlock('ajaxblog/adminhtml_Ajaxblogpost_edit_tab_formadvance')->toHtml(),
      ));
     
      return parent::_beforeToHtml();
  }
}