<?php

class Clarion_Ajaxblog_Block_Adminhtml_Ajaxblogcat_Edit_Tab_Form extends Mage_Adminhtml_Block_Widget_Form
{
  protected function _prepareForm()
  {
      $form = new Varien_Data_Form();
      $this->setForm($form);
      $fieldset = $form->addFieldset('ajaxblogcat_form', array('legend'=>Mage::helper('ajaxblog')->__('Item information')));
     
    //  $fieldset->addField('cat_id', 'text', array(
        //  'label'     => Mage::helper('ajaxblog')->__('ID'),
          //'class'     => 'required-entry',
          //'required'  => true,
          //'name'      => 'cat_id',
      //));

      $fieldset->addField('title', 'text', array(
          'label'     => Mage::helper('ajaxblog')->__('Title'),
          'required'  => false,
          'name'      => 'title',
   ));
              
              
      $fieldset->addField('sort_order', 'text', array(
          'label'     => Mage::helper('ajaxblog')->__('Sort Order'),
          'required'  => false,
          'name'      => 'sort_order',
	  ));
              
              
      $fieldset->addField('meta_keywords', 'textarea', array(
          'label'     => Mage::helper('ajaxblog')->__('Meta Keywords'),
          'required'  => false,
          'name'      => 'meta_keywords',
	  ));
      
       $fieldset->addField('meta_description', 'textarea', array(
          'label'     => Mage::helper('ajaxblog')->__('Meta Description'),
          'required'  => false,
          'name'      => 'meta_description',
	  ));
              
		

      if ( Mage::getSingleton('adminhtml/session')->getAjaxblogData() )
      {
          $form->setValues(Mage::getSingleton('adminhtml/session')->getAjaxblogData());
          Mage::getSingleton('adminhtml/session')->setAjaxblogData(null);
      } elseif ( Mage::registry('ajaxblogcat_data') ) {
          $form->setValues(Mage::registry('ajaxblogcat_data')->getData());
      }
      return parent::_prepareForm();
  }
}