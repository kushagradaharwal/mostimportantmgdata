<?php
class Clarion_Ajaxblog_Block_Ajaxblogloadmore extends Mage_Core_Block_Template
{
	 protected function _construct()
    {
        parent::_construct();
        $this->setTemplate("ajaxblog/ajaxblogloadmore.phtml");
    }
    
    
    public function _prepareLayout()
    {
       if (Mage::getSingleton("cms/wysiwyg_config")->isEnabled() && ($block = $this->getLayout()->getBlock("head"))) {
        $block->setCanLoadTinyMce(true);
        }
        return parent::_prepareLayout();
    }
    
    public function getAjaxblog()     
     { 
        if (!$this->hasData('ajaxblogpost')) {
            $this->setData('ajaxblogpost', Mage::registry('ajaxblogpost'));
        }
        return $this->getData('ajaxblogpost');
        
     }
    
  
    
}