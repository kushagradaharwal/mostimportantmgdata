<?php
class Clarion_Ajaxblog_IndexController extends Mage_Core_Controller_Front_Action
{
    public function indexAction()
    {
    	
    	/*
    	 * Load an object by id 
    	 * Request looking like:
    	 * http://site.com/ajaxblog?id=15 
    	 *  or
    	 * http://site.com/ajaxblog/id/15 	
    	 */
    	/* 
		$ajaxblog_id = $this->getRequest()->getParam('id');

  		if($ajaxblog_id != null && $ajaxblog_id != '')	{
			$ajaxblog = Mage::getModel('ajaxblog/ajaxblog')->load($ajaxblog_id)->getData();
		} else {
			$ajaxblog = null;
		}	
		*/
		
		 /*
    	 * If no param we load a the last created item
    	 */ 
    	/*
    	if($ajaxblog == null) {
			$resource = Mage::getSingleton('core/resource');
			$read= $resource->getConnection('core_read');
			$ajaxblogTable = $resource->getTableName('ajaxblog');
			
			$select = $read->select()
			   ->from($ajaxblogTable,array('ajaxblog_id','title','content','status'))
			   ->where('status',1)
			   ->order('created_time DESC') ;
			   
			$ajaxblog = $read->fetchRow($select);
		}
		Mage::register('ajaxblog', $ajaxblog);
		*/

			
		$this->loadLayout();     
		$this->renderLayout();
    }
}