<?php

class Clarion_Ajaxblog_Block_Adminhtml_Ajaxblogcomment_Edit_Tab_Form extends Mage_Adminhtml_Block_Widget_Form
{
  protected function _prepareForm()
  {
      $form = new Varien_Data_Form();
      $this->setForm($form);
      $fieldset = $form->addFieldset('ajaxblogcomment_form', array('legend'=>Mage::helper('ajaxblog')->__('Item information')));
     
    //  $fieldset->addField('cat_id', 'text', array(
        //  'label'     => Mage::helper('ajaxblog')->__('ID'),
          //'class'     => 'required-entry',
          //'required'  => true,
          //'name'      => 'cat_id',
      //));

      $fieldset->addField('user', 'text', array(
          'label'     => Mage::helper('ajaxblog')->__('User'),
          'required'  => false,
          'name'      => 'user',
	  ));
      $fieldset->addField('email', 'text', array(
          'label'     => Mage::helper('ajaxblog')->__('Email'),
          'required'  => false,
          'name'      => 'email',
	  ));
       
        $fieldset->addField('status', 'select', array(
          'label'     => Mage::helper('ajaxblog')->__('Status'),
          'name'      => 'status',
          'values'    => array(
              array(
                  'value'     => 1,
                  'label'     => Mage::helper('ajaxblog')->__('Approve'),
              ),

              array(
                  'value'     => 2,
                  'label'     => Mage::helper('ajaxblog')->__('UnApprove'),
              ),
          ),
      ));
  
                
      $fieldset->addField('comment', 'textarea', array(
          'label'     => Mage::helper('ajaxblog')->__('Comment'),
          'required'  => false,
          'style'     => 'width:400px; height:400px;',
          'name'      => 'comment',
	  ));
      
    
		

      if ( Mage::getSingleton('adminhtml/session')->getAjaxblogData() )
      {
          $form->setValues(Mage::getSingleton('adminhtml/session')->getAjaxblogData());
          Mage::getSingleton('adminhtml/session')->setAjaxblogData(null);
      } elseif ( Mage::registry('ajaxblogcomment_data') ) {
          $form->setValues(Mage::registry('ajaxblogcomment_data')->getData());
      }
      return parent::_prepareForm();
  }
}