<?php

$installer = $this;

$installer->startSetup();


$installer->run("ALTER TABLE ajaxblogcomment ADD parent_id INT( 11 )  NOT NULL AFTER post_id ;");


$installer->endSetup(); 