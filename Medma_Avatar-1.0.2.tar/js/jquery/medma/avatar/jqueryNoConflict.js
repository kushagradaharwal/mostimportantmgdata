/* 
 * Medma_Avatar
 */

$j = jQuery.noConflict();
