<?php

class Medma_Avatar_Model_Config{

	const AVATAR_ATTR_CODE = 'medma_avatar';
}
