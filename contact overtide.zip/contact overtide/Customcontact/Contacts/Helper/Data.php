<?php

class Customcontact_Contacts_Helper_Data extends Mage_Core_Helper_Abstract
{

}