<?php

class Clarion_Orderfeedback_Block_Adminhtml_Orderfeedback_Edit_Tab_Form extends Mage_Adminhtml_Block_Widget_Form
{
  protected function _prepareForm()
  {
      $form = new Varien_Data_Form();
      $this->setForm($form);
      $fieldset = $form->addFieldset('orderfeedback_form', array('legend'=>Mage::helper('orderfeedback')->__('Item information')));
     
      $fieldset->addField('title', 'text', array(
          'label'     => Mage::helper('orderfeedback')->__('Title'),
          'class'     => 'required-entry',
          'required'  => true,
          'name'      => 'title',
      ));

      $fieldset->addField('filename', 'file', array(
          'label'     => Mage::helper('orderfeedback')->__('File'),
          'required'  => false,
          'name'      => 'filename',
	  ));
		
      $fieldset->addField('status', 'select', array(
          'label'     => Mage::helper('orderfeedback')->__('Status'),
          'name'      => 'status',
          'values'    => array(
              array(
                  'value'     => 1,
                  'label'     => Mage::helper('orderfeedback')->__('Enabled'),
              ),

              array(
                  'value'     => 2,
                  'label'     => Mage::helper('orderfeedback')->__('Disabled'),
              ),
          ),
      ));
     
      $fieldset->addField('content', 'editor', array(
          'name'      => 'content',
          'label'     => Mage::helper('orderfeedback')->__('Content'),
          'title'     => Mage::helper('orderfeedback')->__('Content'),
          'style'     => 'width:700px; height:500px;',
          'wysiwyg'   => false,
          'required'  => true,
      ));
     
      if ( Mage::getSingleton('adminhtml/session')->getOrderfeedbackData() )
      {
          $form->setValues(Mage::getSingleton('adminhtml/session')->getOrderfeedbackData());
          Mage::getSingleton('adminhtml/session')->setOrderfeedbackData(null);
      } elseif ( Mage::registry('orderfeedback_data') ) {
          $form->setValues(Mage::registry('orderfeedback_data')->getData());
      }
      return parent::_prepareForm();
  }
}