<?php

class Clarion_Orderfeedback_Helper_Data extends Mage_Core_Helper_Abstract
{

    
    public function getFormurl()
    {
          return Mage::getBaseUrl()."orderfeedback/orderfeedback/submit";
    }
}