<?php
class Clarion_Orderfeedback_IndexController extends Mage_Core_Controller_Front_Action
{
    public function indexAction()
    {
    	
    	/*
    	 * Load an object by id 
    	 * Request looking like:
    	 * http://site.com/orderfeedback?id=15 
    	 *  or
    	 * http://site.com/orderfeedback/id/15 	
    	 */
    	/* 
		$orderfeedback_id = $this->getRequest()->getParam('id');

  		if($orderfeedback_id != null && $orderfeedback_id != '')	{
			$orderfeedback = Mage::getModel('orderfeedback/orderfeedback')->load($orderfeedback_id)->getData();
		} else {
			$orderfeedback = null;
		}	
		*/
		
		 /*
    	 * If no param we load a the last created item
    	 */ 
    	/*
    	if($orderfeedback == null) {
			$resource = Mage::getSingleton('core/resource');
			$read= $resource->getConnection('core_read');
			$orderfeedbackTable = $resource->getTableName('orderfeedback');
			
			$select = $read->select()
			   ->from($orderfeedbackTable,array('orderfeedback_id','title','content','status'))
			   ->where('status',1)
			   ->order('created_time DESC') ;
			   
			$orderfeedback = $read->fetchRow($select);
		}
		Mage::register('orderfeedback', $orderfeedback);
		*/

			
		$this->loadLayout();     
		$this->renderLayout();
    }
}